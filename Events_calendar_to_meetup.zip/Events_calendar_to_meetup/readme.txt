Contributors: knoxweb
Tags: meetup, meetup post by wordpress ,meetup api
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
 
== Description ==
This plugin will auto post Events in Meetup.com Group on behalf of a Meetup.com organizer which is specified in Settings.
The Events Calendar is required for use this plugin.
You can decide if event you are creating or editing need to plubished to Meetup.com or not while creating Event in wp-admin
You can give additional information which is only display in meetup.
In Plugin Settings you can add api key and vanue id of meetup.

